from django.shortcuts import render, redirect


def sobre(request):
    if request.method == 'POST':
        return redirect('frufrudalara:produtos')
    return render(request, "frufrudalara/tela1.html")


def produtos(request):
    destaques = [
        {"imagem": "frufrudalara/img/tapete-flor-lilas.jpg",      "nome": "Tapete Flor Lilás",    "badge": "Mais vendido"},
        {"imagem": "frufrudalara/img/tapete-girassol.jpg",         "nome": "Tapete Girassol",      "badge": "Novo"},
        {"imagem": "frufrudalara/img/kit-banheiro-coracao.jpg",    "nome": "Kit Banheiro Coração", "badge": "Lançamento"},
    ]
    produtos_lista = [
        {"imagem": "frufrudalara/img/tapete-flor-lilas.jpg",      "nome": "Tapete Flor Lilás",    "preco": "R$ 79,90"},
        {"imagem": "frufrudalara/img/kit-sala-floral.jpg",         "nome": "Kit Sala Floral",      "preco": "R$ 149,90"},
        {"imagem": "frufrudalara/img/tapete-girassol.jpg",         "nome": "Tapete Girassol",      "preco": "R$ 79,90"},
        {"imagem": "frufrudalara/img/passadeira-azul.jpg",         "nome": "Passadeira Azul",      "preco": "R$ 89,90"},
        {"imagem": "frufrudalara/img/passadeira-petroleo.jpg",     "nome": "Passadeira Petróleo",  "preco": "R$ 99,90"},
        {"imagem": "frufrudalara/img/kit-banheiro-coracao.jpg",    "nome": "Kit Banheiro Coração", "preco": "R$ 89,90"},
    ]
    context = {"destaques": destaques, "produtos_lista": produtos_lista}
    return render(request, "frufrudalara/tela3.html", context)
